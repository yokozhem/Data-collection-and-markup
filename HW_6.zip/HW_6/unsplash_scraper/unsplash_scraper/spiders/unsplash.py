"""
Урок 6. Scrapy. Парсинг фото и файлов
Создайте новый проект Scrapy. Дайте ему подходящее имя и убедитесь, что ваше окружение правильно настроено для работы с проектом.
Создайте нового паука, способного перемещаться по сайту www.unsplash.com. Ваш паук должен уметь перемещаться по категориям фотографий и получать доступ к страницам отдельных фотографий.
Определите элемент (Item) в Scrapy, который будет представлять изображение. Ваш элемент должен включать такие детали, как URL изображения, название изображения и категорию, к которой оно принадлежит.
Используйте Scrapy ImagesPipeline для загрузки изображений. Обязательно установите параметр IMAGES_STORE в файле settings.py. Убедитесь, что ваш паук правильно выдает элементы изображений, которые может обработать ImagesPipeline.
Сохраните дополнительные сведения об изображениях (название, категория) в CSV-файле. Каждая строка должна соответствовать одному изображению и содержать URL изображения, локальный путь к файлу (после загрузки), название и категорию.
"""
# рабочий код  но кривые названия

import scrapy
from scrapy_playwright.page import PageMethod
from scrapy.pipelines.images import ImagesPipeline
import csv
import os
from urllib.parse import urlparse

class UnsplashSpider(scrapy.Spider):
    name = "unsplash"
    start_urls = ['https://unsplash.com/']

    def start_requests(self):
        for url in self.start_urls:
            yield scrapy.Request(url, self.parse, meta={
                'playwright': True,
                'playwright_page_methods': [
                    PageMethod('scrollTo', {'top': 999999}),
                    PageMethod('waitForTimeout', 5000)
                ]
            })

    def parse(self, response):
        seen_urls = set()

        # Получение URL изображений и заголовков
        image_urls = response.xpath('//img/@src').extract()
        titles = response.xpath('//img/@alt').extract()

        csv_file = 'images.csv'
        if not os.path.exists('images'):
            os.makedirs('images')

        with open(csv_file, 'w', newline='', encoding='utf-8') as file:
            csv_writer = csv.writer(file)
            csv_writer.writerow(['URL', 'Local Path', 'Title', ])

            for i, image_url in enumerate(image_urls):
                if image_url in seen_urls:
                    continue  # Пропустить дубликаты
                seen_urls.add(image_url)

                # Проверка на Base64 и маленькие изображения
                if image_url.startswith('data:image/') or "small" in image_url or "preview" in image_url:
                    continue

                title = titles[i] if i < len(titles) else 'No title'
                image_guid = urlparse(image_url).path.split('/')[-1].split('?')[0]
                local_path = f'images/{image_guid}'
                csv_writer.writerow([image_url, local_path, title])

                yield {'image_urls': [image_url], 'title': title}

class CustomImagesPipeline(ImagesPipeline):
    def get_media_requests(self, item, info):
        for image_url in item.get('image_urls', []):
            yield scrapy.Request(image_url)

    def file_path(self, request, response=None, info=None, *, item=None):
        image_guid = urlparse(request.url).path.split('/')[-1].split('?')[0]
        return f'images/{image_guid}'


